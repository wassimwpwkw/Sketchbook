package com.sketchbot.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.PointF
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import kotlin.random.Random

class DrawService : AccessibilityService() {

    companion object { var instance: DrawService? = null }

    private val handler = Handler(Looper.getMainLooper())
    @Volatile private var running = false

    override fun onServiceConnected() { instance = this }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() { running = false }
    override fun onDestroy() { running = false; instance = null; super.onDestroy() }

    fun stop() { running = false; handler.removeCallbacksAndMessages(null) }

    fun drawStrokes(strokes: List<List<PointF>>) {
        running = true
        drawNext(strokes, 0)
    }

    private fun drawNext(strokes: List<List<PointF>>, i: Int) {
        if (!running || i >= strokes.size) { running = false; return }

        val pts = strokes[i].map {
            PointF(it.x + Random.nextFloat() * 4 - 2, it.y + Random.nextFloat() * 4 - 2)
        }
        if (pts.size < 2) { drawNext(strokes, i + 1); return }

        val path = Path().apply {
            moveTo(pts[0].x, pts[0].y)
            for (k in 1 until pts.size) {
                val p0 = pts[k - 1]; val p1 = pts[k]
                quadTo(p0.x, p0.y, (p0.x + p1.x) / 2, (p0.y + p1.y) / 2)
            }
        }

        val duration = Random.nextLong(250, 900)
        val stroke = GestureDescription.StrokeDescription(path, 0, duration)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()

        dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(g: GestureDescription?) {
                val pause = if (Random.nextInt(10) == 0)
                    Random.nextLong(1500, 4000)
                else Random.nextLong(150, 700)
                handler.postDelayed({ drawNext(strokes, i + 1) }, pause)
            }
            override fun onCancelled(g: GestureDescription?) { running = false }
        }, null)
    }
}
