package com.sketchbot.app

import android.app.Activity
import android.content.Intent
import android.graphics.PointF
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)

        val info = TextView(this).apply {
            text = "1) فعّل الخدمة من إعدادات الوصول\n" +
                   "2) اضغط Start ثم افتح Sketchbook وكانفس فارغ خلال 5 ثوانٍ"
            textSize = 16f
            gravity = Gravity.CENTER
        }
        val btnAcc = Button(this).apply { text = "تفعيل الخدمة" }
        val btnStart = Button(this).apply { text = "Start" }
        val btnStop = Button(this).apply { text = "Stop" }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(48, 48, 48, 48)
            addView(info); addView(btnAcc); addView(btnStart); addView(btnStop)
        }
        setContentView(root)

        btnAcc.setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        btnStop.setOnClickListener { DrawService.instance?.stop() }
        btnStart.setOnClickListener {
            val svc = DrawService.instance
            if (svc == null) {
                Toast.makeText(this, "فعّل الخدمة أولاً", Toast.LENGTH_LONG).show()
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                return@setOnClickListener
            }
            Toast.makeText(this, "سيبدأ الرسم بعد 5 ثوانٍ", Toast.LENGTH_SHORT).show()
            Handler(Looper.getMainLooper()).postDelayed({
                val demo = listOf(
                    List(30) { PointF(300f + it * 15, 800f + Math.sin(it / 4.0).toFloat() * 60) },
                    List(30) { PointF(300f + it * 15, 1000f + Math.cos(it / 4.0).toFloat() * 60) }
                )
                svc.drawStrokes(demo)
            }, 5000)
        }
    }
}
